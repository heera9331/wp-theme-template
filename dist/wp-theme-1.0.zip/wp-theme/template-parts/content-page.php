


<div class="container-sm"> 
    <div class="">
        <?php the_content(); ?> 
    </div>

    
    <hr>
    <p>template is => content-page.php</p>
    <hr>
</div>