<div class="p-4 bg-dark text-white">
	<?php wp_footer(); ?>
	<div>
    <p class="text-center">copyrights@2024</p>
	</div>
	<hr>
	<p>footer.php</p>
	<hr>
</div>
</div>
</body>
</html>