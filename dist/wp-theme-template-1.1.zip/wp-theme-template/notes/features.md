# Features

- menus
- title-tag
- custom logo
- post-thumbnail
- widget
- sidebar => left, right
-
