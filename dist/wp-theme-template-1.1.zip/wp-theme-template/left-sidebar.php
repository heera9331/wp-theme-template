<?php if (is_active_sidebar('left-sidebar')): ?>
    <aside class="widget-area">
        <?php dynamic_sidebar('left-sidebar'); ?>
    </aside>
<?php endif; ?>