<?php if (is_active_sidebar('right-sidebar')) : ?>
    <aside id="secondary" class="widget-area">
        <?php dynamic_sidebar('right-sidebar'); ?>
    </aside><!-- #secondary -->
<?php endif; ?>
