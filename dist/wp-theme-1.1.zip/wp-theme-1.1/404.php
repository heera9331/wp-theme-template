<?php get_header(); ?>

<div class="container">
    <article>
         <h1 class="font-bold text-2xl">Page note found</h1>
    </article>
    
    <?php get_search_form(); ?>

    <hr>
    <p> template is => 404.php</p>
    <hr>
</div>
  
<?php get_footer(); ?>