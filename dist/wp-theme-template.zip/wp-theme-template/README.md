# wp-theme-template

This is the general template for building a new theme.
